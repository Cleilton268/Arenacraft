package com.phanix.arenacraft

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.widget.EditText
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Casca mínima: abre o ArenaCraft (seu servidor no Termux via ngrok) em tela cheia.
 * O jogo em si continua sendo o ArenaCraft.html servido pelo server.js.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermRequest: PermissionRequest? = null

    private val prefs by lazy { getSharedPreferences("arena", MODE_PRIVATE) }
    private fun gameUrl(): String =
        prefs.getString("url", null) ?: getString(R.string.game_url)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        root = FrameLayout(this)
        web = WebView(this)
        root.addView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        // Teclado: encolhe a área do jogo (igual ao Chrome) sem quebrar a tela cheia.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            v.setPadding(0, 0, 0, ime)
            insets
        }
        hideSystemBars()

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
            textZoom = 100
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.setBackgroundColor(0xFF2B2B2B.toInt())
        WebView.setWebContentsDebuggingEnabled(true)

        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) askForUrl("Não consegui abrir o jogo.\nConfira se o servidor e o ngrok estão ligados, ou troque o link:")
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Links de outros sites abrem no navegador; o jogo fica dentro do app.
                val host = request.url.host ?: return false
                val mine = Uri.parse(gameUrl()).host
                if (host == mine) return false
                startActivity(Intent(Intent.ACTION_VIEW, request.url))
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            // Microfone (mensagens de áudio do chat)
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.resources)
                    } else {
                        pendingPermRequest = request
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
                    }
                }
            }
            // Escolher arquivo (<input type="file">)
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try {
                    startActivityForResult(params.createIntent(), 78); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Deixa o próprio jogo tratar o "voltar" (pausa/menus); não fecha o app sem querer.
                web.evaluateJavascript("window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape'}))", null)
            }
        })

        if (savedInstanceState == null) loadGame() else web.restoreState(savedInstanceState)
    }

    private fun loadGame() {
        // O ngrok grátis mostra uma página de aviso; este cabeçalho pula ela.
        web.loadUrl(gameUrl(), mapOf("ngrok-skip-browser-warning" to "true"))
    }

    private fun askForUrl(msg: String) {
        if (isFinishing) return
        val input = EditText(this).apply { setText(gameUrl()); setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("ArenaCraft")
            .setMessage(msg)
            .setView(input)
            .setPositiveButton("Tentar de novo") { _, _ ->
                var u = input.text.toString().trim().trimEnd('/')
                if (u.isNotEmpty()) {
                    if (!u.startsWith("http")) u = "https://$u"
                    prefs.edit().putString("url", u).apply()
                }
                loadGame()
            }
            .setNegativeButton("Fechar") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 77) {
            val ok = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
            val r = pendingPermRequest; pendingPermRequest = null
            if (ok) r?.grant(r.resources) else r?.deny()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 78) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }
    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
